The capital of France is **Paris**. 

Paris has been the capital of France since the 12th century and is not only the political center of the country but also its cultural, economic, and historical heart. It's home to iconic landmarks like the Eiffel Tower, the Louvre Museum, and Notre-Dame Cathedral.