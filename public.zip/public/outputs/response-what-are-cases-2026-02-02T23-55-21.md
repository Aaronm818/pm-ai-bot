You have **4 active support cases** right now:

1. **Login issues** (task-0) - Customer portal is down, users unable to access accounts
2. **Billing discrepancy** (task-1) - Invoice #4521 has a double charge issue
3. **Password reset not working** (task-2) - Reset emails aren't being delivered
4. **Feature request** (task-3) - Export to PDF functionality (low priority enhancement)

All four cases are currently active and need attention. Would you like me to help prioritize these or get more details on any specific case?