You have **4 active cases** in your queue:

1. **Login issues - Customer portal down** - Customer unable to access account
2. **Billing discrepancy - Invoice #4521** - Customer charged twice  
3. **Password reset not working** - Reset email not arriving
4. **Feature request - Export to PDF** - Low priority enhancement

All four cases are currently active and awaiting action. Would you like me to help you prioritize these or get more details on any specific case?