Based on what I can see on your screen, here are your files:

**Main Project Folder:**
- **Two AI Projects 2026** (in Documents) which contains:
  - **acs-teams-recording** - appears to be your main project directory

**Visible Files:**
- **First start Grok ngrok http 3001.txt** - currently open in your text editor, contains startup instructions for running your server (npm run start:dev) and ngrok commands (ngrok http 3000, ws://localhost:3000/ws)
- **Tts.service.TS** - a TypeScript service file visible in the chat area

This looks like a Teams recording project with server setup documentation and TypeScript service files. The ngrok setup suggests you're doing local development with external webhook/tunnel access. Is there something specific you'd like to do with these files?