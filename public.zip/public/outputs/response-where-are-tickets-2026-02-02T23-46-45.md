You have **4 active support tickets** in the system:

1. **Login issues - Customer portal down** - Customer unable to access account
2. **Billing discrepancy - Invoice #4521** - Customer charged twice  
3. **Password reset not working** - Reset email not arriving
4. **Feature request - Export to PDF** - Low priority enhancement

All four tickets are currently in Active status. Would you like me to help you prioritize these or provide more details about any specific ticket?